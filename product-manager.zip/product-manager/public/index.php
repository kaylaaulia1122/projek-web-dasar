<?php
session_start();
require_once __DIR__ . '/../config/db.php';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$q = trim($_GET['q'] ?? '');
$category_filter = trim($_GET['category'] ?? '');

$sql = "SELECT id, name, category, price, stock, created_at FROM products WHERE 1=1";
$params = [];

if ($q !== '') {
    $sql .= " AND (name LIKE :q OR category LIKE :q)";
    $params['q'] = "%$q%";
}

if ($category_filter !== '') {
    $sql .= " AND category = :category";
    $params['category'] = $category_filter;
}

$sql .= " ORDER BY id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$total_products = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$total_inventory_value = $pdo->query("SELECT SUM(price * stock) FROM products")->fetchColumn() ?? 0;
$low_stock_count = $pdo->query("SELECT COUNT(*) FROM products WHERE stock <= 5")->fetchColumn();

$categories_stmt = $pdo->query("SELECT DISTINCT category FROM products ORDER BY category ASC");
$categories = $categories_stmt->fetchAll(PDO::FETCH_COLUMN);

$status = $_GET['status'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Manager - Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-slate-50 font-sans text-slate-800 antialiased min-h-screen">

    <header class="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <div class="bg-blue-600 text-white p-2 rounded-lg">
                    <i class="fa-solid fa-boxes-stacked text-xl"></i>
                </div>
                <h1 class="text-xl font-bold text-slate-900 tracking-tight">Product Manager</h1>
            </div>
            <a href="create.php" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium shadow-sm transition flex items-center gap-2">
                <i class="fa-solid fa-plus text-sm"></i> Tambah Produk
            </a>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        <?php if ($status): ?>
            <div id="toast-alert" class="mb-6 p-4 rounded-xl border flex items-center justify-between shadow-sm transition-all duration-300
                <?= $status === 'created' || $status === 'updated' || $status === 'deleted' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-red-50 border-red-200 text-red-800' ?>">
                <div class="flex items-center gap-3">
                    <i class="fa-solid <?= $status === 'deleted' ? 'fa-trash-can' : 'fa-circle-check' ?> text-lg"></i>
                    <p class="font-medium">
                        <?php
                            if ($status === 'created') echo "Produk baru berhasil ditambahkan!";
                            elseif ($status === 'updated') echo "Data produk berhasil diperbarui!";
                            elseif ($status === 'deleted') echo "Produk telah berhasil dihapus.";
                        ?>
                    </p>
                </div>
                <button onclick="document.getElementById('toast-alert').remove();" class="text-slate-400 hover:text-slate-600">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
            <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
                <div class="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center text-xl">
                    <i class="fa-solid fa-box"></i>
                </div>
                <div>
                    <p class="text-xs uppercase font-semibold text-slate-400 tracking-wider">Total Produk</p>
                    <h3 class="text-2xl font-bold text-slate-900"><?= number_format($total_products) ?></h3>
                </div>
            </div>
            <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
                <div class="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center text-xl">
                    <i class="fa-solid fa-wallet"></i>
                </div>
                <div>
                    <p class="text-xs uppercase font-semibold text-slate-400 tracking-wider">Nilai Inventaris</p>
                    <h3 class="text-2xl font-bold text-slate-900">Rp <?= number_format($total_inventory_value, 0, ',', '.') ?></h3>
                </div>
            </div>
            <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
                <div class="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center text-xl">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                </div>
                <div>
                    <p class="text-xs uppercase font-semibold text-slate-400 tracking-wider">Stok Menipis (≤5)</p>
                    <h3 class="text-2xl font-bold text-slate-900"><?= number_format($low_stock_count) ?></h3>
                </div>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm mb-6">
            <form method="GET" action="index.php" class="flex flex-col md:flex-row gap-3">
                <div class="relative flex-1">
                    <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input type="text" name="q" value="<?= htmlspecialchars($q, ENT_QUOTES, 'UTF-8') ?>" placeholder="Cari nama atau kategori..."
                        class="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                </div>
                <select name="category" class="px-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm bg-white">
                    <option value="">Semua Kategori</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat, ENT_QUOTES, 'UTF-8') ?>" <?= $category_filter === $cat ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat, ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="bg-slate-800 hover:bg-slate-900 text-white px-5 py-2 rounded-xl text-sm font-medium transition flex items-center justify-center gap-2">
                    <i class="fa-solid fa-filter text-xs"></i> Filter
                </button>
                <?php if ($q !== '' || $category_filter !== ''): ?>
                    <a href="index.php" class="bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-2 rounded-xl text-sm font-medium transition flex items-center justify-center">Reset</a>
                <?php endif; ?>
            </form>
        </div>

        <?php if (empty($products)): ?>
            <div class="bg-white border border-slate-200 rounded-2xl p-12 text-center max-w-md mx-auto my-8 shadow-sm">
                <div class="w-16 h-16 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
                    <i class="fa-solid fa-folder-open"></i>
                </div>
                <h4 class="text-lg font-bold text-slate-800 mb-1">Produk Tidak Ditemukan</h4>
                <p class="text-slate-500 text-sm mb-5">Tidak ada data produk yang sesuai dengan kriteria pencarian Anda.</p>
                <a href="create.php" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition">
                    <i class="fa-solid fa-plus"></i> Tambah Produk Baru
                </a>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($products as $p): ?>
                    <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition flex flex-col justify-between">
                        <div>
                            <div class="flex items-center justify-between mb-3">
                                <span class="bg-slate-100 text-slate-700 text-xs font-semibold px-2.5 py-1 rounded-md uppercase tracking-wider">
                                    <?= htmlspecialchars($p['category'], ENT_QUOTES, 'UTF-8') ?>
                                </span>
                                <?php if ($p['stock'] > 10): ?>
                                    <span class="bg-emerald-100 text-emerald-700 text-xs font-medium px-2.5 py-1 rounded-full flex items-center gap-1.5">
                                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Stok Tersedia
                                    </span>
                                <?php elseif ($p['stock'] > 0): ?>
                                    <span class="bg-amber-100 text-amber-700 text-xs font-medium px-2.5 py-1 rounded-full flex items-center gap-1.5">
                                        <span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span> Stok Menipis
                                    </span>
                                <?php else: ?>
                                    <span class="bg-rose-100 text-rose-700 text-xs font-medium px-2.5 py-1 rounded-full flex items-center gap-1.5">
                                        <span class="w-1.5 h-1.5 rounded-full bg-rose-500"></span> Stok Habis
                                    </span>
                                <?php endif; ?>
                            </div>

                            <h3 class="text-lg font-bold text-slate-900 mb-2 line-clamp-2">
                                <?= htmlspecialchars($p['name'], ENT_QUOTES, 'UTF-8') ?>
                            </h3>

                            <div class="mt-4 pt-4 border-t border-slate-100 grid grid-cols-2 gap-2">
                                <div>
                                    <p class="text-xs text-slate-400 font-medium">Harga Unit</p>
                                    <p class="text-base font-extrabold text-blue-600">Rp <?= number_format($p['price'], 0, ',', '.') ?></p>
                                </div>
                                <div>
                                    <p class="text-xs text-slate-400 font-medium">Sisa Stok</p>
                                    <p class="text-base font-bold text-slate-700"><?= number_format($p['stock']) ?> unit</p>
                                </div>
                            </div>
                        </div>

                        <div class="mt-6 pt-4 border-t border-slate-100 flex items-center gap-2">
                            <a href="edit.php?id=<?= (int)$p['id'] ?>" class="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 py-2 rounded-xl text-center text-sm font-semibold transition flex items-center justify-center gap-1.5">
                                <i class="fa-solid fa-pen-to-square text-xs"></i> Edit
                            </a>
                            <button type="button" onclick="openDeleteModal(<?= (int)$p['id'] ?>, '<?= htmlspecialchars(addslashes($p['name']), ENT_QUOTES, 'UTF-8') ?>')" 
                                class="flex-1 bg-rose-50 hover:bg-rose-100 text-rose-600 py-2 rounded-xl text-center text-sm font-semibold transition flex items-center justify-center gap-1.5">
                                <i class="fa-solid fa-trash-can text-xs"></i> Hapus
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

    <div id="deleteModal" class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center hidden opacity-0 transition-opacity duration-200">
        <div class="bg-white rounded-2xl p-6 max-w-sm w-full mx-4 shadow-xl">
            <div class="w-12 h-12 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-4 text-xl">
                <i class="fa-solid fa-triangle-exclamation"></i>
            </div>
            <h3 class="text-lg font-bold text-slate-900 text-center mb-1">Konfirmasi Hapus</h3>
            <p class="text-slate-500 text-sm text-center mb-6">Apakah Anda yakin ingin menghapus <span id="modalProductName" class="font-bold text-slate-800"></span>? Tindakan ini tidak dapat dibatalkan.</p>
            
            <form method="POST" action="delete.php" class="flex gap-3">
                <input type="hidden" name="id" id="modalProductId">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>">
                <button type="button" onclick="closeDeleteModal()" class="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 rounded-xl text-sm font-semibold transition">Batal</button>
                <button type="submit" class="flex-1 bg-rose-600 hover:bg-rose-700 text-white py-2.5 rounded-xl text-sm font-semibold transition shadow-sm">Hapus</button>
            </form>
        </div>
    </div>

    <script>
        function openDeleteModal(id, name) {
            document.getElementById('modalProductId').value = id;
            document.getElementById('modalProductName').innerText = name;
            const modal = document.getElementById('deleteModal');
            modal.classList.remove('hidden');
            setTimeout(() => modal.classList.remove('opacity-0'), 10);
        }

        function closeDeleteModal() {
            const modal = document.getElementById('deleteModal');
            modal.classList.add('opacity-0');
            setTimeout(() => modal.classList.add('hidden'), 200);
        }
    </script>
</body>
</html>