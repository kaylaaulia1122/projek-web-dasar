<?php
session_start();
require_once __DIR__ . '/../config/db.php';

$errors = [];
$name = '';
$category = 'Umum';
$price = '';
$stock = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? 'Umum');
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    $stock = filter_input(INPUT_POST, 'stock', FILTER_VALIDATE_INT);

    if (mb_strlen($name) < 3) {
        $errors['name'] = 'Nama produk minimal harus 3 karakter.';
    }
    if ($category === '') {
        $errors['category'] = 'Kategori produk wajib diisi.';
    }
    if ($price === false || $price <= 0) {
        $errors['price'] = 'Harga produk harus bernilai lebih dari 0.';
    }
    if ($stock === false || $stock < 0) {
        $errors['stock'] = 'Stok tidak boleh bernilai negatif.';
    }

    if (empty($errors['name'])) {
        $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE name = :name");
        $check_stmt->execute(['name' => $name]);
        if ($check_stmt->fetchColumn() > 0) {
            $errors['name'] = 'Nama produk sudah terdaftar. Gunakan nama lain.';
        }
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO products (name, category, price, stock) VALUES (:name, :category, :price, :stock)");
        $stmt->execute([
            'name' => $name,
            'category' => $category,
            'price' => $price,
            'stock' => $stock
        ]);

        header("Location: index.php?status=created");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk Baru - Product Manager</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-slate-50 font-sans text-slate-800 antialiased min-h-screen py-10">

    <div class="max-w-xl mx-auto px-4">
        <a href="index.php" class="inline-flex items-center gap-2 text-slate-500 hover:text-slate-800 text-sm font-semibold mb-6 transition">
            <i class="fa-solid fa-arrow-left"></i> Kembali ke Dashboard
        </a>

        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-8">
            <div class="mb-6">
                <h2 class="text-2xl font-bold text-slate-900">Tambah Produk Baru</h2>
                <p class="text-slate-500 text-sm mt-1">Lengkapi formulir di bawah ini untuk menambahkan inventaris baru.</p>
            </div>

            <form action="create.php" method="POST" class="space-y-5">
                <div>
                    <label for="name" class="block text-sm font-semibold text-slate-700 mb-1">Nama Produk *</label>
                    <input type="text" id="name" name="name" value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>" minlength="3" required
                        class="w-full px-4 py-2.5 rounded-xl border <?= isset($errors['name']) ? 'border-rose-500 focus:ring-rose-500' : 'border-slate-200 focus:ring-blue-500' ?> focus:outline-none focus:ring-2 text-sm">
                    <?php if (isset($errors['name'])): ?>
                        <p class="text-xs text-rose-500 font-medium mt-1"><?= $errors['name'] ?></p>
                    <?php endif; ?>
                </div>

                <div>
                    <label for="category" class="block text-sm font-semibold text-slate-700 mb-1">Kategori *</label>
                    <input type="text" id="category" name="category" value="<?= htmlspecialchars($category, ENT_QUOTES, 'UTF-8') ?>" required placeholder="Contoh: Elektronik, Pakaian"
                        class="w-full px-4 py-2.5 rounded-xl border <?= isset($errors['category']) ? 'border-rose-500 focus:ring-rose-500' : 'border-slate-200 focus:ring-blue-500' ?> focus:outline-none focus:ring-2 text-sm">
                    <?php if (isset($errors['category'])): ?>
                        <p class="text-xs text-rose-500 font-medium mt-1"><?= $errors['category'] ?></p>
                    <?php endif; ?>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label for="price" class="block text-sm font-semibold text-slate-700 mb-1">Harga (Rp) *</label>
                        <input type="number" id="price" name="price" step="0.01" min="1" value="<?= htmlspecialchars((string)$price, ENT_QUOTES, 'UTF-8') ?>" required
                            class="w-full px-4 py-2.5 rounded-xl border <?= isset($errors['price']) ? 'border-rose-500 focus:ring-rose-500' : 'border-slate-200 focus:ring-blue-500' ?> focus:outline-none focus:ring-2 text-sm">
                        <?php if (isset($errors['price'])): ?>
                            <p class="text-xs text-rose-500 font-medium mt-1"><?= $errors['price'] ?></p>
                        <?php endif; ?>
                    </div>
                    <div>
                        <label for="stock" class="block text-sm font-semibold text-slate-700 mb-1">Jumlah Stok *</label>
                        <input type="number" id="stock" name="stock" min="0" value="<?= htmlspecialchars((string)$stock, ENT_QUOTES, 'UTF-8') ?>" required
                            class="w-full px-4 py-2.5 rounded-xl border <?= isset($errors['stock']) ? 'border-rose-500 focus:ring-rose-500' : 'border-slate-200 focus:ring-blue-500' ?> focus:outline-none focus:ring-2 text-sm">
                        <?php if (isset($errors['stock'])): ?>
                            <p class="text-xs text-rose-500 font-medium mt-1"><?= $errors['stock'] ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="pt-4 border-t border-slate-100 flex items-center gap-3">
                    <a href="index.php" class="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 rounded-xl text-center text-sm font-semibold transition">Batal</a>
                    <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-xl text-sm font-semibold transition shadow-sm">Simpan Produk</button>
                </div>
            </form>
        </div>
    </div>

</body>
</html>